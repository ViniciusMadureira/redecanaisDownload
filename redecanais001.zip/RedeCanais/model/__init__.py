__author__ = "Vinícius Silva Madureira Pereira <contato@viniciusmadureira.com>"
__date__ = "$Jul 7, 2017 7:10:28 PM$"